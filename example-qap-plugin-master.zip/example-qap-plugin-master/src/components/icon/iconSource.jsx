import {Iconfont} from 'nuke';
Iconfont({name: 'iconsforyourapp', url: 'https://at.alicdn.com/t/font_w0iu3docuw4mfgvi.ttf'});

export default {
    // 设置
    setting: '\ue61c',
    // 首页
    home: '\ue615',
    // 评价
    evaluate: '\ue611',
    // 短信
    msg: '\ue618',
    // 订单
    order: '\ue606',

    home1: '\ue8e6',
    evaluate1: '\ue8f5',
    setting1: '\ue8f9',
    msg1: '\ue8ee',
    diamond: '\ue8df',
    paperplane: '\ue8f3',
    search: '\ue8f8',
    note: '\ue8f2',
    calendar: '\ue8d8'
}
